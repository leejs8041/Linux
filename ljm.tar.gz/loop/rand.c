#include <stdio.h>
#include <stdlib.h>


int main(int argc, char*argv[])
{
	int n;
	srand(atoi(argv[1]));
	n = rand()%100;
	printf("%d\n",n);











	return 0;
}
