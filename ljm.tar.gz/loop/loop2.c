#include <stdio.h>

int main(int argc, char*argv[])
{
	int n;
	n = 10;
	
	while(n<10)
	{
	printf("%d\n",n);
	n++;
	}
	printf("======================================\n");

	n =10;
	do
	{
	printf("%d\n",n);
	n++;
	}while(n<10);
	printf("======================================\n");

	return 0;
}
