#include <stdio.h>

int main(int argc, char*argv[])
{
	int n, i, j;
	printf("소수를 알아보는 프로그램\n");
	printf("수를 입력하세요 : \n");

	scanf("%d\n",&n);



	for(i=2; i<=n; i++)
{

		for(j = 2; j<i; j++)
	{
		if(i%j==0)
{
		break;
	}
}
	if (i == j)
	printf("%d\n",n);

}


	return 0;
}
