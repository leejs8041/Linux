#include <stdio.h>

int main(int argc, char*argv[])
{
	int n;
	for(n=13; n<=100; n+=2)
	printf("숫자 : %d\n",n);







	return 0;
}
