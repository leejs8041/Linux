#include <stdio.h>
#include <sqlite3.h>
#include <string.h>

struct dict{
	char word[20];
	int  len;

};

void  dict_set(struct dict *w, char *word){

	int n;
	if(w == NULL || word == NULL)
		return;
	n = strlen(word);
	strncpy(w->word,word,n);
	w->len = n;

}


void dict_print(struct dict *w){

	if(w == NULL)
		return;
	printf("%s - %d\n",w->word,w->len);

}

void dict_sqlinsert(struct dict *w, char *sqlbuffer){
	if(w == NULL || sqlbuffer ==NULL)
		return;
	sprintf(sqlbuffer,"insert into words values('%s',%d);\n",w->word,w->len);

}


int main(int argc, char*argv[])
{
	sqlite3 * db;
	FILE *f;
	int n;
	struct dict myword;
	char word_name[20];
	char sql_buffer[255];




	n = sqlite3_open("mywords.db",&db);
	if(n!=SQLITE_OK){
		printf("SQLITE Open failed\n");
		fclose(f);
		return 0;
	}

	f = fopen("/usr/share/dict/words","r");
	while(feof(f)==0){
		fscanf(f,"%s,%d",word_name,strlen(word_name));
		dict_set(&myword,word_name);
		dict_print(&myword);
		dict_sqlinsert(&myword,sql_buffer);
		printf("%d : %s\n", n++ , sql_buffer);
		//printf("insert into words values('%s',%d);\n",word_name,strlen(word_name));
		//sprintf(sql_buffer,"insert into words values('%s',%d);\n",word_name,strlen(word_name));
		sqlite3_exec(db,sql_buffer,NULL,NULL,NULL);

	}
	sqlite3_close(db);
	fclose(f);



	return 0;
}
