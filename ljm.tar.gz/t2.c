#include <stdio.h>

int main(int argc, char*argv[])
{
	int x, y, z;
	x = 10;
	y = 20;
	z = 10;
	printf("참 or 거짓 : %d\n", x>y);
	printf("참 or 거짓 : %d\n", x<y);
	printf("동일한가 : %d\n", x==z);
	printf("동일한가 : %d\n", y ==z); 
	
	
	
	return 0;
}
