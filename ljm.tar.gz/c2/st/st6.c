#include <stdio.h>

struct stA{
	int n,m;
	char c1,c2;
	
};
struct stB{
	long ln;
	int n;
	long lm;
	int m;
};

union uA{
	int m;
	int n;
	int x;
};
struct color_e{
	char r,g,b,x;
};

union uColor{
	int n;
	struct color_e element;
};

int main(int argc, char*argv[])
{
	struct stA struct_one;
	struct stB struct_two;

	union uA my_union;
	union uColor my_color;

	my_color.element.r = 0;
	my_color.element.g = 0;
	my_color.element.b = 255;
	my_color.element.x = 0xff;


	printf("my_color : %d,0x%x\n",my_color.n,my_color.n);
	my_union.m = 100;

	my_color.n=0x00808080;
	printf("%d,%d,%d\n",my_color.element.r,my_color.element.g,my_color.element.b);

	printf("m : %d\n",my_union.m);
	printf("n : %d\n",my_union.n);
	printf("x : %d\n",my_union.x);
	printf("size of stA %d\n",sizeof(struct_one));
	printf("%d\n",sizeof(struct stA));

	printf("size of stB %d\n",sizeof(struct_two));
	printf("%d\n",sizeof(struct stB));

	return 0;
}
