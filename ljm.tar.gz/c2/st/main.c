#include <stdio.h>
#include <sqlite3.h>



int main(int argc, char * argv[])
{
	sqlite3 *db;
	FILE *f;
	int rc;

	rc = sqlite3_open("db1.db",&db);
	//f = fopen("abc","r");

	rc = sqlite3_exec(db,"insert into t1 values(3,'abc');",NULL,NULL,NULL);


	sqlite3_close(db);
	//fclose(f);

	return 0;
}
