#include <stdio.h>

void fn1(){
	printf("fn1\n");
};

void fn2(int n, void (*x)(void)){
	printf("%d - fn2\n",n);
	if(n > 5)
		x();
}


int main(int argc, char*argv[])
{
	fn2(1,fn1);
	fn2(10,fn1);

	return 0;
}
