#ifndef __WT_H__ 
#define __WT_H__

#define BASE_URL "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/"
#define FN3	"getVilageFcst"

typedef enum{
	XML,
	JSON
}RET_DTYPE;

struct wturl{
	char serviceKey[100];
	int numOfRows;
	int pageNo;
	char dataType[5];
	char base_date[9];
	char base_time[5];
	int nx;
	int ny;
};

struct wturl *wturl_create();
void wturl_destroy(struct wturl *s);
void wturl_set_serviceKey(struct wturl *s, char *k);
void wturl_set_serviceKey_from_file(struct wturl *s, char *fn);
void wturl_set_numOfRows(struct wturl *s, int n);
void wturl_set_pageNo(struct wturl *s, int n);
void wturl_set_dataType(struct wturl *s, char *dt);
void wturl_set_dataType2(struct wturl *s, RET_DTYPE t);
void wturl_set_base_date(struct wturl *s, char *bd);
void wturl_set_base_time(struct wturl *s, char *bt);
void wturl_set_date_time_now(struct wturl *s);
void wturl_set_xy(struct wturl *s, int x, int y);
void wturl_print(struct wturl *s);
void wturl_build_url(struct wturl *s, char *buffer);

char *wtxml_get_value(char *xml_buffer, char *keyword);

#endif
