#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "libwt.h"

struct wturl *wturl_create(){

	struct wturl *ret = NULL;

	ret = (struct wturl*)malloc(sizeof(struct wturl));
	if(ret == NULL)
		return NULL;

	ret->numOfRows = 10;
	ret->pageNo = 1;
	strncpy(ret->dataType, "XML", strlen("XML"));

	return ret;
}

void wturl_destroy(struct wturl *s){
	if(s!=NULL)
		free(s);
}

void wturl_set_serviceKey(struct wturl *s, char *k){
	if(s == NULL || k == NULL)
		return;

	strncpy(s->serviceKey, k, strlen(k));
}

void wturl_set_serviceKey_from_file(struct wturl *s, char *fn){
	FILE *f = NULL;
	char buff[100];

	if(s == NULL || fn == NULL)
		return;

	f = fopen(fn, "r");
	if(f == NULL)
		return;

	fscanf(f, "%s", buff);
	fclose(f);

	//strncpy(s->serviceKey, buff, strlen(buff));
	wturl_set_serviceKey(s, buff);
}

void wturl_set_numOfRows(struct wturl *s, int n){
	if(s!=NULL)
		s->numOfRows = n;
}

void wturl_set_pageNo(struct wturl *s, int n){
	if(s!=NULL)
		s->pageNo = n;
}

void wturl_set_dataType(struct wturl *s, char *dt){
	if(s == NULL || dt == NULL)
		return;
	strncpy(s->dataType, dt, strlen(dt));
}

void wturl_set_dataType2(struct wturl *s, RET_DTYPE t){
	if(s==NULL)
		return;

	switch(t){
	case XML:
		strncpy(s->dataType, "XML", 3);
		s->dataType[3]='\0';
		break;
	case JSON:
		strncpy(s->dataType, "JSON", 4);
		s->dataType[4]='\0';
		break;
	}
}



void wturl_set_base_date(struct wturl *s, char *bd){
	if(s == NULL || bd == NULL)
		return;
	strncpy(s->base_date, bd, strlen(bd));
}

void wturl_set_base_time(struct wturl *s, char *bt){
	if(s == NULL || bt == NULL)
		return;
	strncpy(s->base_time, bt, strlen(bt));
}

void wturl_set_date_time_now(struct wturl *s){

	time_t t_now;
	struct tm *t = NULL;
	
	if(s == NULL)
		return;

	t_now = time(NULL);
	t = localtime(&t_now);
	if(t == NULL)
		return;

	sprintf(s->base_date,"%d%02d%02d", 
			t->tm_year+1900,
			t->tm_mon+1,
			t->tm_mday);
	s->base_date[8]='\0';
	sprintf(s->base_time, "%02d%02d",
			t->tm_hour, t->tm_min);
	s->base_time[4]='\0';
}

void wturl_set_xy(struct wturl *s, int x, int y){
	if(s!=NULL){
		s->nx = x;
		s->ny = y;
	}
}

void wturl_print(struct wturl *s){
	if(s== NULL){
		printf("Null pointer\n");
		return;
	}
	printf("serviceKey: %s\n", s->serviceKey);
	printf("numOfRows: %d\n",  s->numOfRows);
	printf("pageNo: %d\n", s->pageNo);
	printf("dataType: %s\n", s->dataType);
	printf("base_date: %s\n", s->base_date);
	printf("base_time: %s\n", s->base_time);
	printf("nx: %d, ny:%d\n", s->nx, s->ny);
}

void wturl_build_url(struct wturl *s, char *buffer){
	if(s == NULL || buffer == NULL)
		return;

	sprintf(buffer,
		"%s%s?serviceKey=%s&numOfRows=%d&pageNo=%d&base_date=%s&base_time=%s&nx=%d&ny=%d&dataType=%s",
		BASE_URL, FN3,
		s->serviceKey, s->numOfRows, s->pageNo,
		s->base_date, s->base_time, s->nx, s->ny, s->dataType); 
}

char *wtxml_get_value(char *xml_buffer, char *keyword){

	char *m1 = NULL, *m2, *m3;
	char *ret = NULL;
	int len;

	m1 = strstr(xml_buffer, keyword);
	if(m1 == NULL)
		return NULL;
	m2 = strstr(m1, "<fcstValue>");
	m2 += strlen("<fcstValue>");
	m3 = strstr(m2, "</fcstValue>");

	len = m3 - m2;
	ret = (char*) malloc(len+1);
	strncpy(ret, m2, len);
	ret[len]='\0';
	return ret;
}
