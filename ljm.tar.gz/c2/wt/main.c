#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <curl/curl.h>
#include "libwt.h"

char xml_buffer[48452];
int xml_buffer_index = 0;

size_t get_result(char *p, size_t s, size_t n, void *d){

	size_t len;
	len = s*n;

	strncpy(xml_buffer + xml_buffer_index, p, len);
	xml_buffer_index += len;

	return len;
}

int main(int argc, char *argv[]){

	struct wturl *murl;
	char url_buffer[300], *ans, query_str[10];
	CURL *curl = NULL;
	int opt, nx, ny;

	while((opt = getopt(argc, argv, "x:y:q:"))!=-1){
		switch(opt){
		case 'x':
			nx = atoi(optarg);
			break;
		case 'y':
			ny = atoi(optarg);
			break;
		case 'q':
			strcpy(query_str, optarg);
			break;
		}
	}

	murl = wturl_create();
	wturl_set_serviceKey_from_file(murl, "wt_key");
	wturl_set_date_time_now(murl);
	wturl_set_base_time(murl, "2000");
	wturl_set_dataType2(murl, XML);
	//wturl_set_xy(murl, 97, 74);
	wturl_set_xy(murl, nx, ny);
	wturl_build_url(murl, url_buffer);
	wturl_destroy(murl);

	printf("%s\n", url_buffer);

	curl = curl_easy_init();
	curl_easy_setopt(curl, CURLOPT_URL, url_buffer);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, get_result);
	curl_easy_perform(curl);
	curl_easy_cleanup(curl);

	printf("%s\n", xml_buffer);

	ans = wtxml_get_value(xml_buffer, query_str);

	printf("ans(%s): %s\n", query_str, ans);
	free(ans);

	return 0;
}
