#include <iostream>
#include <string.h>

using namespace std;

class Person{
	protected:
		int num;
		char *name;
	public:
	Person(){
		cout<<"person - const"<<endl;
		name = new char[20];
	}
	~Person(){
		cout<<"person - dest"<<endl;
		delete name;
	}
	void set_num(int n){
		num = n;
	}
	void set_name(const char *s){
		strcpy(name, s);
	}
	virtual void print(){
		cout<<"Person"<<num<<" "<<name<<endl;
	}
};

class Student : public Person{
	private:
		float gpa;
	public:
	Student(){
		cout<<"const - student"<<endl;
	}
	~Student(){
		cout<<"dest - student"<<endl;
	}
	void set_gpa(float f){
		gpa = f;
	}
	void print(){
		cout<<"Student"<<num<<" "<<gpa<<" "<<name<<endl;
		//cout<<"Student"<<gpa<<endl;
	}
};

class Diner{
	public:
	void check_customer(Person *p){
		cout<<"******check_customer"<<endl;
		p->print();
	}
};

int main(int argc, char *argv[]){

	Person *myman;
	Student *myman2;
	Diner	*zip;

	myman = new Person();
	myman->set_num(100);
	myman->set_name("abc");
	myman->print();

	myman2 = new Student();
	myman2->set_num(200);
	myman2->set_name("def");
	myman2->set_gpa(4.0);
	myman2->print();

	zip = new Diner();
	zip->check_customer(myman);
	zip->check_customer(myman2);


	return 0;
}
