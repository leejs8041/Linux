#include <iostream>
#include <stdio.h>

using namespace std;

class testA{

	private:
		int n;

		void private_method(){
			cout<<"private"<<endl;
		}

	public:
		testA(){
			n = 1000;
			cout<<"constructor - tesA"<<endl;
		}

		~testA(){
			cout<<"destructor - tesA"<<endl;
		}

		void test_function(){
			n = 100;
			cout<<n<<endl;
		}

		void test_function2(){
			cout<<n<<endl;
		}

};

class testB : public testA{



	public:
		testB(){

			cout<<"constructor - testB"<<endl;
		}

		~testB(){
			cout<<"destructor - testB"<<endl;
		}

	void test_function2(){
		cout<<"overriding testA-Funtion2"<<endl;
		}

	void print_value(int n){
		cout<<"int version : "<<n<<endl;
	}
	void print_value(float n){
		cout<<"float version : "<<n<<endl;
	}

};


int main(int argc, char*argv[]){


	testB myclass_2;
	float x = 10.123;

	myclass_2.test_function2();
	myclass_2.print_value(10);
	myclass_2.print_value(x);
	return 0;
}
