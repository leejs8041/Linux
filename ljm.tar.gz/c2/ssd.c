#include <stdio.h>

#define TARGET_N 100

int sum_of_squares(int n){
	int ret;
	ret = 0;
	while(n>0){
		ret+=n*n;
		n--;
	}

	return ret;
}

void square_of_sum(int n, int *ret){

	int sum = 0;
	while(n>0){
		n--;
	}
	*ret = sum*sum;

}

int main(int argc, char *argv[]){
	int r1, r2;

	r1 = sum_of_squares(TARGET_N);
	square_of_sum(TARGET_N, &r2);

	printf("%d, %d, %d\n", r1, r2, r2-r1);

	return 0;
}
