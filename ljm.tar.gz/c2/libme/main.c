#include <stdio.h>
#include "libme.h"


int main(int argc, char *argv[]){


	libme_test();
	return 0;
}
