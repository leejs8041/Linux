#include <stdio.h>
#include <curl/curl.h>
#include <string.h>

char html_buffer[1024];
int html_buffer_offset = 0;

size_t fill_buffer(char*ptr, size_t s, size_t nmemb, void *d){
	size_t x;
	x = s*nmemb;

	strncpy(html_buffer+html_buffer_offset,ptr,x);
	html_buffer_offset +=x;
	return x;
}




int main(int argc, char *argv[])
{

	CURL *c = NULL;
	c = curl_easy_init();


	curl_easy_setopt(c,CURLOPT_URL,"192.168.4.103");
	curl_easy_setopt(c,CURLOPT_WRITEFUNCTION, fill_buffer);
	curl_easy_perform(c);
	curl_easy_cleanup(c);

	printf("%s\n",html_buffer);

	char *s1, *s2, final[100];
	int s_len;

	s1 = strstr(html_buffer,"<!");
	s1 += strlen("<!");

	s2 = strstr(s1,">");
	s_len = s2 - s1;
	strncpy(final, s1, s_len);

	printf("s1 : %s\n", s1);
	printf("s2 : %s\n", s2);
	printf("final : %s\n", final);

	return 0;
}
