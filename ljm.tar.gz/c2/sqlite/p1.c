#include <stdio.h>
#include <sqlite3.h>

int main(int argc, char*argv[])
{
	sqlite3 *db;
	FILE *f;
	int r,g,b;
	char color_name[30];
	char sql_buffer[255];
	int rc;

	sqlite3_open("colors.db",&db);



	f = fopen("colors","r");
	while(feof(f)==0){
		fscanf(f,"%d,%d,%d %s",&r,&g,&b,color_name);
		printf("insert into colors values(%d,%d,%d,'%s');\n",r,g,b,color_name);
		sprintf(sql_buffer,"insert into colors values(%d,%d,%d,'%s');\n",r,g,b,color_name);
		sqlite3_exec(db,sql_buffer,NULL,NULL,NULL);
		//printf("%s\n",sql_buffer);
	}
	sqlite3_close(db);

	fclose(f);

	

	return 0;
}
