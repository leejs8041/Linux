#include <stdio.h>


int main(int argc, char*argv[])
{
	char buffer[50];

	int n;

	n = 100;
	for(n=0;n<100;n++){

		sprintf(buffer,"insert into t1 values(%d,'abc');",n);
		printf("%s\n",buffer);
	}

	return 0;
}
