#include <stdio.h>

int main(int argc, char *argv[])
{
	int a = 2*5;
	int b = 7/3;
	int c = a+b;

	
	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n",++c);
	printf("====================================\n");

	
	
	if(c%2==1)
	printf("c is odd\n");

	else if(c>12)
	printf("c is greater than 12\n");

	else if(c>10)
	printf("c is greater than 10\n");



	return 0;





}
