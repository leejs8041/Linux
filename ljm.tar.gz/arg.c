#include <stdio.h>

int main(int argc, char*argv[])
{
	int n;
	printf("%d\n",argc);
	printf("%s\n",argv[0]);



	return 0;
}
