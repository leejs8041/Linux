#include <stdio.h>

void by_val(int n)
{
	printf("%d\n",n);
	n = 100;

}

void by_ref(int *n)
{
	printf("%d\n",*n);
	*n = 100;
}
void m1(char *x, int i)
{
	int n;
	for(n=0;n<i;n++)
	{
		*(x+n)+=10;
	}


}





int main(int argc, char *argv[])
{
	int n = 5;
	char m[6] = {'a','b','c','d','e','\0'};
	char *str1 = "mystring";

	by_val(n);
	printf("main1 : %d\n", n);
	by_ref(&n);
	printf("main2 : %d\n", n);

	m1(m,5);
	for(n=0;n<5;n++)
		printf("%c\n",m[n]);

	//*(str1+8) = 'a';
	printf("%s\n",str1);
	return 0;
}
