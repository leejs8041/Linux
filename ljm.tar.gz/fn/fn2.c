#include <stdio.h>






int isPrime(int i){
	int n;
	for(n=2; n<i-1; n++)
	{
		if(i%n==0)
			return 0;

	}
	return 1;
}



int main(int argc, char*argv[])
{
	int n,i;
	printf("find prime numbers under : ");
	scanf("%d",&n);
	//int n;
	//n = 13;
	for(i=2;i<n+1;i++)
	{
		if(isPrime(i)==1)
			printf("%d\n",i);
	}
	printf("\n");






	return 0;
}
