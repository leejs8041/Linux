#include <stdio.h>

void fn2(int n);


int fn1(int n){
	printf("printf from fn1 %d\n",n);
	return n+100;

}




int main(int argc, char*argv[])
{
	int x;

	x = fn1(10);
	fn2(3);
	printf("return from fn1 : %d\n", x);



	return 0;
}


void fn2(int n){
	printf("printf from fn2 %d\n", n);
}
