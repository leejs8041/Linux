#include <stdio.h>

int main(int argc, char*argv[])
{
	int n;
	n = 6;

	switch(n)
	{
	case 1 :
		printf("n is 1\n");
		break;


	case 2 :
		printf("n is 2\n");
		break;

	case 3 :
		printf("n is 3\n");
		break;

	default:
		printf("null\n");
	}


	return 0;
}
