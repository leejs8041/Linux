#include <stdio.h>
#include <stdlib.h>

typedef struct _point{
	int x, y;
}POINT;

//typedef struct point POINT;


int main(int argc, char *argv[])
{
	POINT  mypoint;
	POINT mypoint2[10];
	POINT *mypoint3;
	int n;

	mypoint.x = 10;
	mypoint.y = 20;

	printf("%d, %d\n",mypoint.x,mypoint.y);

	for(n=0;n<10;n++){
		mypoint2[n].x = n;
		mypoint2[n].y = n*10;
}

	for(n=0;n<10;n++)
	printf("%d,%d - %d\n",n,mypoint2[n].x,mypoint2[n].y);


	mypoint3 = (POINT*)malloc(sizeof(POINT));


	mypoint3->x = 50;
	mypoint3->y = 150;

	printf("%d, %d\n", mypoint3->x,mypoint3->y);
	free(mypoint3);

	return 0;
}
