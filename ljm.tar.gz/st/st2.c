#include <stdio.h>
#include <time.h>




int main(int argc, char*argv[])
{
	time_t t_now;
	struct tm *t=NULL;

	t_now = time(NULL);
	printf("%ld\n",t_now);
	


	t = localtime(&t_now);
	t->tm_year;
	t->tm_mon;
	t->tm_mday;
	printf("%d년, %d월, %d일\n",t->tm_year+1900,t->tm_mon+1,t->tm_mday);
	



	return 0;
}
