#include <stdio.h>

int main(int argc, char*argv[])
{
	FILE *f = NULL;
	f = fopen("myfile", "w");

	fprintf(f,"hello\n");


	fclose(f);



	return 0;
}
