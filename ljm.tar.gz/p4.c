#include <stdio.h>

int main(int argc, char*argv[])
{
	int n = 5;

	if(n==1)

	printf("n is 1\n");

	else if(n==2)

	printf("n is 2\n");

	else if(n==3)

	printf("n is 3\n");

	else

	printf("null\n");

	printf("=================================\n");

	int a = 5;
	switch(a%2)
{
	case 1 : 
		printf("a is odd\n");
		break;

	case 2 :
		printf("a is even\n");
		break;


}





	return 0;
}
