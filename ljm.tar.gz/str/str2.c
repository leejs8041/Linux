#include <stdio.h>
#include <string.h>


int main(int argc, char*argv[])
{
	char mystr[50], mystr2[50];
	int n;

	printf("your string: ");
	scanf("%s", mystr);

	printf("len : %d\n", strlen(mystr));
	strcpy(mystr2, mystr+2);
	printf("strcpy : %s\n",mystr2);




	return 0;
}
