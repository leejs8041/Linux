#include <stdio.h>
#include <string.h>

void ccrypt_r(char *text, int c)
{
	int i;
	int n=10;
	for(i=0; i<n; i++){

	if(*text+i != '0'){
			
		printf("%c",*(text+i)+3);
		break;
		*(text+i) = c;
	}else{
		break;
}


}
}

void ccrypt_l(char *text, int c){



}



int main(int argc, char*argv[])
{
	char plain_text[50];

	strcpy(plain_text, "message");
	
	ccrypt_r(plain_text,3);
	printf("%s\n",plain_text);


	return 0;
}
