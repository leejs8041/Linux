#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void abc(char *s)
{
	int n;
	char mystr[n];
	



}


int main(int argc, char*argv[])
{
	char *mystr;
	int n;
	printf("your string : ");


	mystr = (char*)malloc(sizeof(char)*n);
	scanf("%s",mystr);

	abc(mystr);
	printf("len : %d\n", (strlen(mystr)));
	free(mystr);



	return 0;
}
