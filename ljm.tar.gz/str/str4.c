#include <stdio.h>
#include <string.h>

void strchr_practice(){
	char *mystr = "mystring";
	char *ret = NULL;

	ret = strchr(mystr, 's');

	
	if(ret == NULL){
		printf("not found\n");
		return;
	}else{
	printf("0x%x, %d\n", ret, ret-mystr);
}

}

void strstr_pratice(){
	char *mystr = "mystring";
	char *ret;

	ret = strstr(mystr, "str");
	printf("0x%x, %d\n", ret, ret-mystr);

}


void strcmp_practice(){

	char *str1 = "mystring";
	char *str2 = "mystring";
	int ret;

	ret = strcmp(str1,str2);

	printf("%d\n",ret);


}

int main(int argc, char*argv[])
{
	strchr_practice();
	//strstr_pratice();
	//strcmp_practice();


	return 0;
}
