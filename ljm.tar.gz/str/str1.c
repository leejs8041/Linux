#include <stdio.h>
#include <stdlib.h>


void to_upper(char *s)
{
	int i;
	char c;

	if(s==NULL)
		return;

	c = *s;
	for(i = 0; c!='\0'; )
	{
		c = *(s+i);
		printf("to_upper: %c\n", c);
		*(s+i)-=32;
		i++;
		c = *(s+i);

	}

	c=*s;
	//while(1){
	//		if(c=='\0')
	//			break;
	//		printf("to_upper : %c\n",c);
	//		i++;
	//		c= *(s+i);

	//		}

}








int main(int argc, char*argv[])
{
	char *name;
	int n;

	printf("length of your name : ");
	scanf("%d",&n);


	name = (char*)malloc(sizeof(char)*n);

	printf("your name: ");
	scanf("%s",name);
	//*(name+3) = '\0';
	to_upper(name);
	printf("your name is %s\n", name);

	free(name);
	return 0;
}
