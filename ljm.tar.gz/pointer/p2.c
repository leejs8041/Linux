#include <stdio.h>
#include <stdlib.h>


int main(int argc, char*argv[])
 {
	int *np = NULL;
	int n,m;
	int arr[10];
	printf("number count : ");
	scanf("%d",&n);
	np = (int*)malloc(sizeof(int)*n);

	*np =5; 
	*(np+1) = 10; 
	*(np+2) = 15; 
	for(m=0;m<n; m++) {
		printf("number[%d] : ", m+1);
		scanf("%d", np+m);


	}
	for(m=0;m<n; m++) {

	printf("%d,0x%x\n",*(np+m), np+m);
	}
	free(np);

	return 0;
}
