#include <stdio.h>


int main(int argc, char*argv[])
{
	int n;
	int *np;
	int arr[5] = {1,2,3,4,5};


	n = 5;
	printf("%d, 0x%x\n", n, &n);
	np = &n;
	printf("0x%x, %d\n",np, *np);
	
	for(n=0;n<5;n++)
	{
		printf("%d,0x%x,0x%x\n",arr[n],&arr[n],arr+n);
	}




	return 0;
}
