#include <stdio.h>
#define PI 3.14


int main(int argc, char *argv[])

{
	int n;
	long l;
	float f;
	double d;
	char c;
	const int x = 20;

	c = 'a';
	n = 5;

	printf("%d\n",n);
	
	n = 10;
	printf("%d\n",n);

	l = 100;
	f = 1.1;
	d = PI;
	
	printf("%d, %d\n", x , sizeof(x));
	printf("%ld, %d\n",l, sizeof(l));
	printf("%f,%d\n",f,sizeof(f));
	printf("%lf,%d\n",d,sizeof(d));
	printf("%d,%c,%d\n",c,c,sizeof(c));
	return 0;

}
