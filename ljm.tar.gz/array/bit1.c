#include <stdio.h>

int main(int argc, char*argv[])
{
	int n,m;

	//for(n=0;n<20;n++)
	//	printf("%d\t0x%x\n",n,n);

	//printf("%d, %x\n", 255,255);

	//m =1;

	//for(n = 0; n<8; n++)
	//	printf("%d\t0x%x\n", m<<n, m<<n);


	//m = 0x80;
	//printf("given hex : %d\n" ,m);



	//for(n =0; n<8; n++)
	//	printf("%d\t0x%x\n", m>>n, m>>n);

	//printf("====================\n");

	//m = 0x2;
	//n = 0x4;
	//int p = 10;
	//printf("%d, 0x%x\n", m&n,m&n);
	//printf("%d, 0x%x\n", m|n,m|n);
	//printf("%d, 0x%x\n",m|n,(m|n)|p);


	m = -1;
	int t = 0x80, i;
	printf("0x%x,", m);
	for(n=0; n<20;n++)
	{
		i = (m & (t>>n));

		if(i==0)
			printf("0");


		else
			printf("1");
		if(n%4==3)
			printf(" ");
	}
	printf("\n");


	return 0;
}
