#include <stdio.h>

int main(int argc, char*argv[])
{
	int n, i;
	int *np;
	int ar[5] = {1,2,3,4,5};

	printf("%d, %d\n", sizeof(n), sizeof(np));
	
	n = 5;
	printf("%d, %x\n", n, &n);

	n = 100;
	printf("%d, %x\n", n , &n);


	np = &n;
	printf("np : %x, %d\n", np, *np);


	*np = 500;
	printf("n: %d\n",n);

	for(i = 0; i<5; i++)
	{
		printf("ar[%d]: %d, %x, %x\n",
			i, ar[i], &(ar[i]), ar+i);
	}





	return 0;
}
