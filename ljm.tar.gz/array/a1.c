#include <stdio.h>

int main(int argc, char*argv[])
{
	int ball[10];
	int n;

	int i = 5;
	int coin[5]={2,4,6,8,10};

	for(n=0; n<10; n++)
		ball[n] = n*n;

	for(n=0; n<10; n++)
		printf("index : %d, value : %d\n", n, ball[n]);


	for(n=0; n<5; n++)
		printf("coin value : %d\n", coin[n]);







	return 0; 
}
