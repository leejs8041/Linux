#include <stdio.h>

int main(int argc, char*argv[])
{
	int arr[2][3] =
	{
		{1,2,3},
		{4,5,6}
	};

	int arr2[3][2], result[2][2];


	int n,m;



	for(n=0; n<3;n++)
	{
		for(m=0; m<2; m++)
		{
			arr2[n][m]=((n+1)*10)+m;
			printf("%d-%d[%x]: %d\n",n,m,&(arr2[n][m]),arr2[n][m]);

		}
	}

	printf("==============\n");

	result[0][0] = arr[0][0]*arr2[0][0] + arr[0][1]*arr2[1][0]+arr[0][2]*arr2[2][0];
	printf("%d\n",result[0][0]);

	result[0][0]=0;

	for(n=0; n<3;n++)
		result[0][0] +=arr[0][n]*arr2[n][0];




	return 0;
}
