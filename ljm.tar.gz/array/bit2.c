#include <stdio.h>
#define OPT1	1
#define OPT2	2
#define OPT3	3





int main(int argc, char*argv[])
{
	unsigned char c;
	char c2;
	unsigned int n;




	c = -1;

	
	printf("%d, 0x%x,", c, c&0xff);
	for(n=0; n<8; n++)
	{
		
		if((c & (0x80>>n))==0)
			printf("0");

		else
			printf("1");
		if(n%4==3)
			printf(" ");
	}
	printf("\n");



	n = 300;
	c2 = n;
	









	return 0;
}
