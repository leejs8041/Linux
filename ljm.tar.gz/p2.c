#include <stdio.h>

int main(int argc,char *argv[])
{
	int a = (2 * 8) + (7 % 3);

	printf("%d\n",a);

	if(a%2==1)

	printf("a is odd\n");

	else

	printf("a is even");

	if(a%3==0)

	printf("a is 3의배수\n");

	else if(a%3!=0)

	printf("a is 3의배수가 아니다\n");






	return 0;
}
