#include <stdio.h>

int main(int argc, char *argv[])
{
	int myval;
	int a = 2;
	int b = 7;
	int c = 100;
	c*=3;
	myval = 20;
	printf("%d\n",myval+a);
	printf("%d\n",myval-a);
	printf("%d\n",myval*a);
	printf("%d\n",myval/a);
	printf("%d\n",myval&a);
	printf("%d\n", b%c);
	printf("%d\n", a++);
	printf("%d\n", ++b);
	printf("%d\n", c);
	printf("%d\n", myval--);
	printf("%d\n", myval);
	return 0;
}
