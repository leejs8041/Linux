#include <stdio.h>
#include <stdlib.h>


int main(int argc, char*argv[])
{
	int n = atoi(argv[1]);


	printf("enter number[0-100] : ");
	scanf("%d",&n);

	if(n>0)
	{
	if(n%2==1)
		printf("n 은 홀수입니다\n");
	
	else
		printf("n 은 짝수입니다\n");
	}

	if(n==0)
		printf("is zero\n");
	else if (n<10)
		printf("class 1\n");
	else if(n<20)
		printf("class 2\n");
	else if(n<30)
		printf("class 3\n");
	else
		printf("null\n");












	return 0;
}
